﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2201561041
{
    internal class Midfield : FootballPlayer
    {
    }
}
