﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2201561041
{
    abstract class FootballPlayer : Person      
    {
         public int Number { get; set; }
         public int Height { get; set; }
    }
}
