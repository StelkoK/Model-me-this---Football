﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2201561041
{
    internal class Team
    {
        public string Coach { get; set; }
        public int Players { get; set; }

        public int AvgAge { get; set; }
    }
}
